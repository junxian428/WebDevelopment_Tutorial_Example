package com.example.demotutor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemotutorApplicationTests {

	@Test
	void contextLoads() {
	}

}
