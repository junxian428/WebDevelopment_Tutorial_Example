package com.example.demotutor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemotutorApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemotutorApplication.class, args);
	}

}
